print ("this is awesome")
