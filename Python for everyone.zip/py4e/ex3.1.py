hrs = input("Enter Hours:")
h = float(hrs)
rate = input("Enter Rate:")
r = float(rate)
if h > 40:  
    regular_pay = h * r
    overtime_pay = (h - 40) * (r * 0.5)
    gross_pay = regular_pay + overtime_pay
else:
    gross_pay = r*h
    
print ("Pay", gross_pay)




