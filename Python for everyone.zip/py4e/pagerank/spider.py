import sqlite3
import urllib.error
import ssl
from urllib.parse import urljoin, urlparse
from urllib.request import urlopen
from bs4 import BeautifulSoup

# ✅ Fix for Python 3.10+ (bs4 / soupsieve compatibility)
import collections
if not hasattr(collections, 'Callable'):
    import collections.abc
    collections.Callable = collections.abc.Callable

# Ignore SSL certificate errors
ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

# Connect to SQLite database
conn = sqlite3.connect('spider.sqlite')
cur = conn.cursor()

# Create tables if they don't exist
cur.execute('''CREATE TABLE IF NOT EXISTS Pages
    (id INTEGER PRIMARY KEY, url TEXT UNIQUE, html TEXT,
     error INTEGER, old_rank REAL, new_rank REAL)''')

cur.execute('''CREATE TABLE IF NOT EXISTS Links
    (from_id INTEGER, to_id INTEGER, UNIQUE(from_id, to_id))''')

cur.execute('''CREATE TABLE IF NOT EXISTS Webs (url TEXT UNIQUE)''')

# Check if a crawl is already in progress
cur.execute('SELECT id,url FROM Pages WHERE html IS NULL AND error IS NULL ORDER BY RANDOM() LIMIT 1')
row = cur.fetchone()
if row is not None:
    print("Restarting existing crawl. Remove spider.sqlite to start fresh.")
else:
    starturl = input('Enter web url or press Enter to use the default: ')
    if len(starturl.strip()) < 1:
        starturl = 'https://www.dr-chuck.com/page1.htm'  # ✅ Working default

    # Normalize URL
    starturl = starturl.strip()
    if starturl.startswith("http://"):
        starturl = starturl.replace("http://", "https://", 1)
    if starturl.endswith('/'):
        starturl = starturl[:-1]

    web = starturl
    if starturl.endswith('.htm') or starturl.endswith('.html'):
        pos = starturl.rfind('/')
        web = starturl[:pos]

    if len(web) > 1:
        cur.execute('INSERT OR IGNORE INTO Webs (url) VALUES ( ? )', (web,))
        cur.execute('INSERT OR IGNORE INTO Pages (url, html, new_rank) VALUES ( ?, NULL, 1.0 )', (starturl,))
        conn.commit()

# Load known websites
cur.execute('SELECT url FROM Webs')
webs = [str(row[0]) for row in cur]
print("Webs to crawl:", webs)

many = 0
while True:
    if many < 1:
        sval = input('How many pages to crawl (or Enter to quit): ')
        if len(sval) < 1:
            break
        many = int(sval)
    many -= 1

    cur.execute('SELECT id,url FROM Pages WHERE html IS NULL AND error IS NULL ORDER BY RANDOM() LIMIT 1')
    row = cur.fetchone()
    if row is None:
        print('No unretrieved HTML pages found')
        break

    fromid, url = row[0], row[1]
    print(fromid, url, end=' ')

    cur.execute('DELETE FROM Links WHERE from_id=?', (fromid,))

    try:
        document = urlopen(url, context=ctx)
        html = document.read()

        if document.getcode() != 200:
            print("Error on page:", document.getcode())
            cur.execute('UPDATE Pages SET error=? WHERE url=?', (document.getcode(), url))
            conn.commit()
            continue

        if document.info().get_content_type() != 'text/html':
            print("Ignoring non-HTML page")
            cur.execute('DELETE FROM Pages WHERE url=?', (url,))
            conn.commit()
            continue

        print(f"({len(html)})", end=' ')
        soup = BeautifulSoup(html, "html.parser")

    except KeyboardInterrupt:
        print('\nProgram interrupted by user...')
        break
    except Exception as e:
        print(f"Unable to retrieve or parse page: {e}")
        cur.execute('UPDATE Pages SET error=-1 WHERE url=?', (url,))
        conn.commit()
        continue

    cur.execute('UPDATE Pages SET html=? WHERE url=?', (memoryview(html), url))
    conn.commit()

    tags = soup('a')
    count = 0
    for tag in tags:
        href = tag.get('href', None)
        if href is None:
            continue

        # Resolve relative links
        up = urlparse(href)
        if len(up.scheme) < 1:
            href = urljoin(url, href)

        ipos = href.find('#')
        if ipos > 1:
            href = href[:ipos]

        if href.endswith(('.png', '.jpg', '.gif', '.pdf', '.css', '.js')):
            continue
        if href.endswith('/'):
            href = href[:-1]
        if len(href) < 1:
            continue

        # Stay within allowed websites
        found = False
        for web in webs:
            if href.startswith(web):
                found = True
                break
        if not found:
            continue

        cur.execute('INSERT OR IGNORE INTO Pages (url, html, new_rank) VALUES ( ?, NULL, 1.0 )', (href,))
        conn.commit()

        cur.execute('SELECT id FROM Pages WHERE url=? LIMIT 1', (href,))
        row = cur.fetchone()
        if row is not None:
            toid = row[0]
            cur.execute('INSERT OR IGNORE INTO Links (from_id, to_id) VALUES (?, ?)', (fromid, toid))
            count += 1

    print(count)
    conn.commit()

cur.close()
print("Crawl complete.")
