score = input("Enter Score: ")
try:
    x = float(score)
    if x > 1.0 or x <0.0:
        print ("Error: Score is out of range. Please enter a value between 0.0 and 1.0")
    elif x >= 0.9:
        print ('A')
    elif x >= 0.8:
        print ('B')
    elif x >= 0.7:
        print ('C')
    elif x >= 0.6:
        print ('D')
    else:    
        print ('F')
except ValueError:
    print("ERROR: Please enter a numeric socre.")