import urllib.request
from bs4 import BeautifulSoup

# Input parameters
url = input('Enter URL: ')
count = int(input('Enter count: '))
position = int(input('Enter position: ')) - 1  # Convert to zero-based index

# Loop through the sequence
for i in range(count):
    print("Retrieving:", url)
    html = urllib.request.urlopen(url).read()
    soup = BeautifulSoup(html, 'html.parser')
    tags = soup.find_all('a')
    url = tags[position].get('href')

# Final retrieval
print("Retrieving:", url)
html = urllib.request.urlopen(url).read()
soup = BeautifulSoup(html, 'html.parser')
final_name = soup.title.string.split()[-1].strip()
print("The answer to the assignment is:", final_name)
