import urllib.request
import xml.etree.ElementTree as ET

# Prompt for URL
url = input('Enter location: ')
print('Retrieving', url)

# Read and decode XML data
data = urllib.request.urlopen(url).read()
print('Retrieved', len(data), 'characters')

# Parse XML
tree = ET.fromstring(data)

# Find all <count> elements
counts = tree.findall('.//count')

# Compute the sum
total = sum(int(count.text) for count in counts)
print('Count:', len(counts))
print('Sum:', total)
