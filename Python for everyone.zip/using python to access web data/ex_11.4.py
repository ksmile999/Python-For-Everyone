import re

# Prompt for file name
fname = input("Enter file name: ")
if len(fname) < 1:
    fname = "regex_sum_2300283.txt"

try:
    with open(fname) as f:
        contents = f.read()
        numbers = re.findall(r'[0-9]+', contents)
        total = 0
        for num in numbers:
            total += int(num)
        print("Sum:", total)
except FileNotFoundError:
    print("File cannot be opened:", fname)


    