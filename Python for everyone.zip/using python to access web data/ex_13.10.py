import urllib.request
import json

# Prompt for URL
url = input('Enter location: ')
print('Retrieving', url)

# Read and decode JSON data
data = urllib.request.urlopen(url).read()
print('Retrieved', len(data), 'characters')

# Parse JSON
info = json.loads(data)

# Extract and sum all 'count' values
total = sum(item['count'] for item in info['comments'])
print('Count:', len(info['comments']))
print('Sum:', total)
