import socket

# Create a socket object using IPv4 and TCP
mysock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server on port 80 (HTTP)
mysock.connect(('data.pr4e.org', 80))

# Properly formatted HTTP GET request (note: no full URL in GET line)
cmd = 'GET /romeo.txt HTTP/1.0\r\nHost: data.pr4e.org\r\n\r\n'.encode()

# Send the request
mysock.send(cmd)

# Receive and print the response in chunks
while True:
    data = mysock.recv(512)
    if len(data) < 1:
        break
    print(data.decode(), end='')  # Avoid double newlines

# Close the socket
mysock.close()
